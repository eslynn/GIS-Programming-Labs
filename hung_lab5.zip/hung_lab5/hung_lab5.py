# Steffi Hung
# GIS Programming and Automation
# Fall 2021

# Lab 5
print("Running lab 5.")
print("")

# Set up steps
import time
t0 = time.time()

import glob
import numpy as np
import pandas as pd
import rasterio as rio
import lab5functions as laf

dat_dir = sorted(glob.glob('./data/*.tif'))
b4_dir = sorted(glob.glob('./data/L5_big_elk/*B4.tif'))
b3_dir = sorted(glob.glob('./data/L5_big_elk/*B3.tif'))

with rio.open(dat_dir[0]) as dem:   
    read_dem = dem.read(1)
with rio.open(dat_dir[1]) as fire_perim:
    read_perim = fire_perim.read(1)
    burned_forest = np.where(read_perim == 1, 1, np.nan)
    healthy_forest = np.where(read_perim == 2, 1, np.nan)

#

#Part 1.1
t = dem.transform
x = t[0]
y =-t[4]
print("Original cell size is", x, 'by', y)
slp, aspect = laf.slopeAspect(read_dem, 30.0)
aspectReclass = laf.reclassAspect(aspect)
slpReclass = laf.reclassByHisto(slp, 10)
#

# Part 1.2
rr_list = []
for x,y in zip(b3_dir, b4_dir):
    b3 = rio.open(x).read(1)
    b4 = rio.open(y).read(1)
    NDVI = ((b4 - b3)/ (b4 + b3))
    healthyNDVI = healthy_forest * NDVI
    mean_healthyNDVI = np.nanmean(healthyNDVI)
    burnedNDVI = burned_forest * NDVI
    rr = burnedNDVI/mean_healthyNDVI
    rr_list.append(rr)
    rr_avg = np.average(rr)
#

# Part 1.4
year_list = []
for year in range(2002, 2012):
    empty_array = np.zeros_like(rr_list[0])
    year_array = np.where(empty_array == 0, year, year)
    year_list.append(year_array)

year_stack = np.vstack(year_list)
rr_stack = np.vstack(rr_list)

rr_stack[np.isnan(rr_stack)] = 0

for rr in rr_list:
    rr[np.isnan(rr)] = 0

flat_year = year_stack.flatten()
flat_rr = rr_stack.flatten()

trend_line = np.polyfit(flat_year, flat_rr, 1)
cor = trend_line[0]

yr = 2002

#

# Part 1.5
print("")
for rr in rr_list:
    print(f'The Recovery Ratio for the year {yr} is', round(np.average(rr), 2))
    yr += 1
print(f'The Coefficient of Recovery for 2002 through 2011 is', round(cor, 3))
print("")
#

#

#Part 2

# Part 2.1
def zstats_table (zoneRaster, valueRaster, csvName):
    zones = np.unique(zoneRaster)
    ztab = {'zones':[], 'min':[], 'max':[],'mean':[],'count':[],'stddev':[]}
    x = 1
    for x in list(zones):
        burn_exc = np.where(zoneRaster == x, 1, np.nan)
        ztab['zones'].append(x)
        ztab['min'].append(np.nanmin(burn_exc * valueRaster))
        ztab['max'].append(np.nanmax(burn_exc * valueRaster))
        ztab['mean'].append(np.nanmean(burn_exc * valueRaster))
        ztab['count'].append(np.nansum(burn_exc))
        ztab['stddev'].append(np.nanstd(burn_exc * valueRaster))
        x = x + 1
    dat_frame = pd.DataFrame(ztab)
    csvName = dat_frame.to_csv(csvName)

# Part 2.2
print("Getting CSV for slope reclass.")
zstats_table(aspectReclass, rr, 'rr_aspect.csv')
print("Getting CSV for slope aspect reclass.")
zstats_table(slpReclass, rr, 'rr_slope.csv')

# Part 2.3
print("Exporting GeoTIFF")
print("")
with rio.open('./data/fire_perimeter.tif') as dat:
    with rio.open ('rr.tif', 'w',
    driver = 'GTIFF',
    height= rr.shape[0],
    width = rr.shape[1],
    count = 1,
    dtype = 'float32',
    crs = dat.crs,
    transform = dat.transform,
    nodata = 0
    ) as out_ras:
        out_ras.write(rr, 1)
#

# Part 2.4
print("Conclusions:")
print("--Slopes with a southern aspect (zones 4-6) showed the highest mean recovery ratios with all being at 0.1 or higher.")
print("--Western facing slopes (zones 6-8) generally showed higher recovery rates than eastern facing slopes(zones 2-4).")
print("--Slopes with a southwestern aspect had the highest mean recovery ratio overall.")
print("--Steeper slopes seemed to show higher recovery rates than less steep slopes.")
print("")

# Lab runtime
tfin = (time.time() - t0) / 60
tfin_round = round(tfin, 2)
if tfin_round > 1.0:
    print("Lab 5 took", tfin_round, "minutes to run.")
else:
    print("Lab 5 took less than a minute to run.")
#

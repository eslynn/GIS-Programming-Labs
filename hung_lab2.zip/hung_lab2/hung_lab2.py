# Steffi Hung
# GIS: Programming and Automation
# Fall 2021
# Lab 2

#

print("Importing libraries and modules.")
import glob
import pandas as pd
import geopandas as gpd

from rasterstats import zonal_stats
from shapely.geometry import Polygon

#

print("Creating directories.")
dist_sp = sorted(glob.glob('./data/districts/*.txt'))
ag_sp = sorted(glob.glob('./data/agriculture/*.tif'))

#

# Part 1

#

print("Reading files.")
dist_ls = []
cord_ls = []
for file in dist_sp:
    dist = file[-6:-4]
    dist_ls.append(dist)

    dist_df = pd.read_csv(file, sep='\t', lineterminator='\r')
    coord = gpd.points_from_xy(dist_df.X, dist_df.Y)
    cord_ls.append(coord)

geom_ls = []
for x in cord_ls:
    geom = Polygon(x)
    geom_ls.append(geom)

#

print("Creating geodataframe for polygons.")
poly_gdf = gpd.GeoDataFrame(dist_ls, cord_ls).reset_index()
poly_gdf = poly_gdf.rename(
    columns={
        "index": "num_coords", 
        0: "districts"
        }
        )
poly_gdf = poly_gdf[['districts', 'num_coords']]
poly_gdf['geometry'] = geom_ls

#

# Part 2

#

print("Calculating the number of agricultural pixels in each district in 2004 and 2009.")
print("")
dist_gdf = gpd.GeoDataFrame(poly_gdf, crs = "EPSG:4326")

for file in ag_sp:
    yr = file[-13:-9]
    ag_mn = zonal_stats(dist_gdf, file, stats=['mean'])

    for idx, stat in enumerate(ag_mn):
        dist_name = dist_gdf.iloc[idx]['districts']
        pct_tot = stat['mean'] * 100
        pct_rnd = round(pct_tot, 2)
        print(f"Agricultural land represented {pct_rnd}% of all the land in district {dist_name} in {yr}.")
        print("")

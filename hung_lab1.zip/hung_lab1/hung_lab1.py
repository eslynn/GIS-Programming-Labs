# Steffi Hung
# GIS: Programming and Automation
# Fall 2020
# Lab 1

# Lab 1
# Part I
# Section 1: "Join each of the tables to the corresponding feature class. Find a common field to join on." (from lab1_f21.pdf)

# imports pandas and geopandas, assigns sourcepath variable
import pandas as pd
import geopandas as gpd 
sp = 'lab1.gpkg'

# imports fiona and saves layer list as a variable
import fiona
sp_layers = fiona.listlayers(sp)
print(sp_layers)

# creates collections for storing the muag tables separately from the soil tables
soilTables = []
muagTables = []
# creates a for loop for separating out the muag tables from the soil tables and storing them in their respective collections
for x in sp_layers:
    if x.startswith("soil"):
        soilTables.append(x)
    if x.startswith("muag"):
        muagTables.append(x)
        
# creates a collection for storing the combined tables after joining them
joinTables = []
# creates 'for loop' for joining tables in muag and soil collections that have same numbers
for x in soilTables:
    for i in muagTables:
        if x[-3:] == i[-3:]:
            soilLayer = gpd.read_file(sp, layer=x)
            muagLayer = gpd.read_file(sp, layer=i)
            muagLayer = muagLayer.drop(columns='geometry')
            joinLayer = soilLayer.join(muagLayer, lsuffix='MUSYM', rsuffix='musym')
            joinTables.append(joinLayer) #adds the tables to collection

# Lab 1
# Part I
# Section 2: "Add a new field named mapunit to each joined feature class and calculate the values for all features as the map unit ID of the feature class. The map unit ID is the suffix of the layer name (e.g., co641)." (from lab1_f21.pdf)
for x in sp_layers:
    for i in joinTables:
        i['mapunit'] = x[-5:]

# Lab 1
# Part I
# Section 3: "Merge the 9 feature classes into a new feature class." (from lab1_f21.pdf)
joined_featureClass = pd.concat(joinTables) #merges the 9 features classes into a new one named joined_featureClass
joined_featureClass

# Lab 1
# Part I
# Section 4: "Intersect the merged feature class with the watershed boundaries." (from lab1_f21.pdf)

# creates variable for the watershed layer
ws_boundaries = gpd.read_file(sp, layer='wbdhu8_lab1')
print(ws_boundaries)

# uses geopandas overlay function to create and intersection between the new feature class in joined_featureClass and watershed layer
iWatershed = gpd.overlay(joined_featureClass, ws_boundaries, how='intersection')

# groups items in iWatershed by NAME column (name of watershed)
iW_grouped = iWatershed.groupby(by='NAME').count()

# Lab 1
# Part II: "Find the number of features in the resulting intersected feature class that correspond to each watershed. Report these two numbers in a print statement at the end of your script." (from lab1_f21.pdf)

for x, row in iW_grouped.iterrows():
    watershed_features = row['SPATIALVER']
    print(f'{watershed_features}' + " features classes in watershed " + x)

print(iW_grouped)
# Code I didn't end up using after all
# but might need again
#
#
# # create directories
# print("Getting directories.")
# src = 'data' # establishes folder as src
# target = 'tif' # tells ext to target
# filing_cabinet_sp = [] # list for tif filepath storage
# get_files = os.listdir(src) # gets all the doc names in src
# # targets tif ext and saves them to list
# for x in get_files:
#     if x.endswith(target):
#         filing_cabinet_sp.append(src + '/' + x)
#
# # opening files
# print("Opening and storing files.")
# open_cabinet = []
# open_files = []
# for idx in filing_cabinet_sp:
#     with rasterio.open(idx) as file_name:
#         open_cabinet.append(file_name)
#         ras_dat = file_name.read(1)
#         open_files.append(ras_dat)

#

# # runs each file in open_files through genFrame
# print("Running moving window.")
# for x in open_files:
#     genFrame(x)
# print(cent_avg)

#

# slope
# rastList = []
# with rasterio.open('data/slope.tif') as slope:
#     dat_slope = slope.read(1)
#     rastList.append(dat_slope)
# # urban
# with rasterio.open('data/urban_areas.tif') as urban:
#     dat_urban = urban.read(1)
#     rastList.append(dat_urban)
# # water bodies
# with rasterio.open('data/water_bodies.tif') as water:
#     water_dat = water.read(1)
#     rastList.append(water_dat)
# # windspeed
# with rasterio.open('data/ws80m.tif') as wind:
#     wind_d = wind.read(1)
#     rastList.append(wind_d)
# # protected
# with rasterio.open('data/protected_areas.tif') as protecc:
#     protecc_dat = protecc.read(1)
#     rastList.append(protecc_dat)
# # print statement
# print("Data import completed.")

#

# # sourcepaths
# slope_sp = 'data/slope.tif'
# urban_sp = 'data/urban_areas.tif'
# water_sp = 'data/water_bodies.tif'
# wind_sp = 'data/ws80m.tif'
# protecc_sp = 'data/protected_areas.tif'
# # open
# slope_o = rasterio.open(slope_sp)
# urban_o = rasterio.open(urban_sp)
# water_o = rasterio.open(water_sp)
# wind_o = rasterio.open(wind_sp)
# protecc_o = rasterio.open(protecc_sp)
# # read
# dat_slope = slope_o.read(1)
# dat_urban = urban_o.read(1)
# water_dat = water_o.read(1)
# wind_d = wind_o.read(1)
# protecc_dat = protecc_o.read(1)
# # slope
# rastList = []
# rastList.append(dat_slope)
# rastList.append(dat_urban)
# rastList.append(water_dat)
# rastList.append(wind_d)
# rastList.append(protecc_dat)

#

# genFrame(dat_slope)
# slope_keeper = []
# slope_keeper.append(mean_keeper)
# mean_keeper.clear()
# genFrame(dat_urban)
# urban_keeper = []
# slope_keeper.append(mean_keeper)
# mean_keeper.clear()
# genFrame(water_dat)
# water_keeper = []
# slope_keeper.append(mean_keeper)
# mean_keeper.clear()
# genFrame(wind_d)
# wind_keeper = []
# slope_keeper.append(mean_keeper)
# mean_keeper.clear()
# genFrame(protecc_dat)
# protecc_keeper = []
# slope_keeper.append(mean_keeper)
# mean_keeper.clear()

#

# def flatten(t):
#     return [item for sublist in t for item in sublist]

#

# # open
# openRasters = []
# slope_o = rasterio.open(slope_sp)
# openRasters.append(slope_o)
# urban_o = rasterio.open(urban_sp)
# openRasters.append(urban_o)
# water_o = rasterio.open(water_sp)
# openRasters.append(water_o)
# wind_o = rasterio.open(wind_sp)
# openRasters.append(wind_o)
# protecc_o = rasterio.open(protecc_sp)
# openRasters.append(protecc_o)

#

# critList = []
# slopeCrit = np.where(cent_avg[0] < 15,1,0)
# critList.append(slopeCrit)
# urbanCrit = np.where(cent_avg[1] == 0,1,0)
# critList.append(urbanCrit)
# waterCrit = np.where(cent_avg[2] < 0.02,1,0)
# critList.append(waterCrit)
# windCrit = np.where(cent_avg[3] > 8.5,1,0)
# critList.append(windCrit)
# proteccCrit = np.where(cent_avg[4] < 0.05,1,0)
# critList.append(proteccCrit)

#

# crit_meet = np.array([cent_avg], dtype='f8')
# def critCheck(dataset, crit):
#     res = all(crit == True for ele in dataset)
#     if x != crit:
#         crit_meet.remove(x)
#     else:
#         print("Criteria met.")
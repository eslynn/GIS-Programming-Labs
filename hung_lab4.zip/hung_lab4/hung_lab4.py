# Steffi Hung
# GIS Programming and Automation
# Fall 2021
# Lab 4

# set up
import time
t0 = time.time()
# package import
print("Now importing packages.")
import rasterio
import numpy as np
import pandas as pd
import warnings
from scipy.spatial import cKDTree

#
warnings.filterwarnings("ignore", category=RuntimeWarning)
#

# sourcepaths
print("Getting pathways.")
spDirect = []
# spDirect index 0
slope_sp = 'data/slope.tif'
spDirect.append(slope_sp)
# spDirect index 1
urban_sp = 'data/urban_areas.tif'
spDirect.append(urban_sp)
# spDirect index 2
water_sp = 'data/water_bodies.tif'
spDirect.append(water_sp)
# spDirect index 3
wind_sp = 'data/ws80m.tif'
spDirect.append(wind_sp)
# spDirect index 4
protecc_sp = 'data/protected_areas.tif'
spDirect.append(protecc_sp)

#

# Moving window function
print("Creating moving window function.")
cent_avg = []
def genFrame (dataset):
    for raster in dataset:
        print("Reading", raster)
        with rasterio.open(raster) as array:
            dat = array.read(1)
            empT_arr = np.zeros_like(dat)
            for row in range(0, dat.shape[0]):
                for col in range(0, dat.shape[1]):
                    window = dat[row:row + 11, col:col + 9]
                    empT_arr[row, col] = (window.sum())/99
            print("Updating center averages.")        
            cent_avg.append(empT_arr)

# run genFrame
print("Running moving window, this may take a while. Now would be a good time to go get some coffee or a snack.")
print("")
genFrame(spDirect)
print("Moving window finished running.")
print("")

# Boolean array evaluation
print("Establishing criteria for evaluation.")
slopeCrit = np.where(cent_avg[0] < 15,1,0)
urbanCrit = np.where(cent_avg[1] == 0,1,0)
waterCrit = np.where(cent_avg[2] < 0.02,1,0)
windCrit = np.where(cent_avg[3] > 8.5,1,0)
proteccCrit = np.where(cent_avg[4] < 0.05,1,0)

# Surface sutiability values summing arrays
print("Combining evaluations.")
critList = (slopeCrit + urbanCrit + waterCrit + windCrit + proteccCrit)

print("Evaluating data for locations that meet all criteria.")
print("")
wellMet = np.where(critList == 5, 1, 0)
print(wellMet.sum(), "locations scored a five.")
print("")

with rasterio.open(spDirect[0]) as dataSlo:
    with rasterio.open('data/wellMetGeotiff.tif', 'w',
        driver = 'GTiff',
        height = wellMet.shape[0],
        width = wellMet.shape[1],
        count = 1,
        dtype = "int8",
        crs=dataSlo.crs,
        transform = dataSlo.transform,
        nodta = dataSlo.nodata
    ) as oRast:
        wellMet = wellMet.astype('int8')
        oRast.write(wellMet, 1)

with rasterio.open('data/wellMetGeotiff') as transf_ds:
    cell_size = transf_ds.transform[0]
    extent = transf_ds.bounds
    x_coords = np.arange(extent[0] + cell_size/2, extent[2], cell_size)
    y_coords = np.arange(extent[1] + cell_size/2, extent[3], cell_size)
    x, y = np.meshgrid(x_coords, y_coords)
    x.flatten(), y.flatten()
    flat_coords = np.c_[x.flatten(), y.flatten()]
    xflat = x.flatten()
    critMet = wellMet.reshape(xflat.shape)
    crit_coords = []
    for i, e in zip(flat_coords, critMet):
        x = np.multiply(i[0],e)
        y = np.multiply(i[1],e)
        if x != 0 and y != 0:
            crit_coords.append([x,y])

    tStats = pd.read_csv("data/transmission_stations.txt")
    x_coord = tStats['X']
    y_coord = tStats['Y']
    stationLoc = np.column_stack([x_coord, y_coord])
    criteria_array = np.array(crit_coords)
    station_array = np.array(stationLoc)

    dist, indexes = cKDTree(criteria_array).query(station_array)
    maxDist = dist.max()/1000
    roundMax = round(maxDist, 2)
    minDist = dist.min()/1000
    roundMin = round(minDist, 2)

    print("The longest distance between the nearest transmission station and a suitable site is:", roundMax, "meters.")
    print("")
    print("The shortest distance between the nearest transmission station and a suitable site is:", roundMin, "meters.")
    print("")

# Printing total process time
tfin = (time.time() - t0) / 60
tfin_round_final = round(tfin, 2)
if tfin_round_final > 1.0:
    print("Entire process completed in", tfin_round_final, "minutes.")
else:
    print("Entire process completed in less than 1 minute.")
